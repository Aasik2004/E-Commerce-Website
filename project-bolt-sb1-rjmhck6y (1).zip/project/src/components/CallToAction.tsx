import React from 'react';
import Button from './ui/Button';

const CallToAction: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-teal-600 to-teal-800 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Grow Your Business?</h2>
          <p className="text-lg mb-8 opacity-90">
            Join thousands of satisfied clients who have transformed their businesses with our professional services
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              variant="primary"
              size="lg"
              className="bg-white text-teal-700 hover:bg-gray-100"
            >
              Get Started
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-teal-700"
            >
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;