import React from 'react';
import { Search } from 'lucide-react';
import Button from './ui/Button';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute -right-10 -top-10 w-72 h-72 bg-white rounded-full" />
        <div className="absolute -left-10 -bottom-10 w-72 h-72 bg-white rounded-full" />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Find the perfect services for your business
          </h1>
          <p className="text-xl mb-8 opacity-90">
            High-quality services by talented professionals to help your business grow and succeed
          </p>
          
          <div className="bg-white rounded-lg p-2 flex items-center max-w-xl mx-auto shadow-lg">
            <Search className="h-5 w-5 text-gray-400 ml-2 flex-shrink-0" />
            <input
              type="text"
              placeholder="What service are you looking for today?"
              className="w-full px-3 py-2 text-gray-800 focus:outline-none"
            />
            <Button className="flex-shrink-0">
              Search
            </Button>
          </div>
          
          <div className="mt-8 flex flex-wrap justify-center gap-3 text-sm opacity-85">
            <span>Popular:</span>
            <a href="/services?category=design" className="hover:underline">Logo Design</a>
            <a href="/services?category=development" className="hover:underline">Web Development</a>
            <a href="/services?category=marketing" className="hover:underline">Social Media</a>
            <a href="/services?category=writing" className="hover:underline">Content Writing</a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;