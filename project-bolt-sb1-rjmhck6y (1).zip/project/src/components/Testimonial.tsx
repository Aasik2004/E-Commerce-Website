import React from 'react';
import { Star } from 'lucide-react';

const Testimonial: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hear from people who have experienced the quality of our services
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Testimonial 1 */}
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 shadow-sm">
            <div className="flex text-amber-500 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-amber-500" />
              ))}
            </div>
            <p className="text-gray-700 mb-6">
              "The logo design service exceeded my expectations. The designer was extremely professional and delivered a stunning logo that perfectly captures our brand essence. Highly recommended!"
            </p>
            <div className="flex items-center">
              <img 
                src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Alex Johnson" 
                className="h-12 w-12 rounded-full object-cover mr-4"
              />
              <div>
                <h4 className="font-medium text-gray-900">Alex Johnson</h4>
                <p className="text-sm text-gray-500">CEO, TechStart</p>
              </div>
            </div>
          </div>
          
          {/* Testimonial 2 */}
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 shadow-sm">
            <div className="flex text-amber-500 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-amber-500" />
              ))}
            </div>
            <p className="text-gray-700 mb-6">
              "Working with GigMarket's web developers was a game-changer for our business. They created a beautiful, functional website that has significantly increased our online presence and customer engagement."
            </p>
            <div className="flex items-center">
              <img 
                src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Sarah Miller" 
                className="h-12 w-12 rounded-full object-cover mr-4"
              />
              <div>
                <h4 className="font-medium text-gray-900">Sarah Miller</h4>
                <p className="text-sm text-gray-500">Marketing Director, Bloom Co.</p>
              </div>
            </div>
          </div>
          
          {/* Testimonial 3 */}
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-100 shadow-sm">
            <div className="flex text-amber-500 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 fill-amber-500" />
              ))}
            </div>
            <p className="text-gray-700 mb-6">
              "The social media management service has transformed our online presence. Our engagement has increased by 200% and we're seeing real business results. The team is responsive and incredibly creative."
            </p>
            <div className="flex items-center">
              <img 
                src="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Michael Chen" 
                className="h-12 w-12 rounded-full object-cover mr-4"
              />
              <div>
                <h4 className="font-medium text-gray-900">Michael Chen</h4>
                <p className="text-sm text-gray-500">Founder, Innovate Labs</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonial;