import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { Service } from '../types';
import { Card, CardContent, CardFooter } from './ui/Card';

interface ServiceCardProps {
  service: Service;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  return (
    <Link to={`/services/${service.id}`}>
      <Card className="h-full transition-all duration-300 hover:shadow-md">
        <div className="relative h-48 overflow-hidden">
          <img 
            src={service.image} 
            alt={service.title} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
          {service.featured && (
            <div className="absolute top-3 right-3 bg-amber-500 text-white text-xs font-bold py-1 px-2 rounded">
              Featured
            </div>
          )}
        </div>
        
        <CardContent className="pb-2">
          <div className="text-sm text-gray-500 mb-1 capitalize">{service.category}</div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2 line-clamp-2">{service.title}</h3>
          <p className="text-gray-600 mb-4 text-sm line-clamp-2">{service.description}</p>
        </CardContent>
        
        <CardFooter className="justify-between border-t border-gray-100 pt-4">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
            <span className="text-sm ml-1 font-medium">{service.rating}</span>
            <span className="text-xs text-gray-500 ml-1">({service.reviews})</span>
          </div>
          <div className="font-semibold text-blue-600">
            ${service.price}
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
};

export default ServiceCard;