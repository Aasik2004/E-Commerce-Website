import { Service, Category, Review } from '../types';

export const services: Service[] = [
  {
    id: '1',
    title: 'Professional Logo Design',
    description: 'I will design a modern, minimal logo for your brand or business. Includes unlimited revisions and all source files.',
    price: 50,
    category: 'design',
    image: 'https://images.pexels.com/photos/6177645/pexels-photo-6177645.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.9,
    reviews: 253,
    deliveryTime: '2 days',
    featured: true
  },
  {
    id: '2',
    title: 'Website Development',
    description: 'I will build a responsive website using React and Tailwind CSS. Includes SEO optimization and basic analytics setup.',
    price: 120,
    category: 'development',
    image: 'https://images.pexels.com/photos/5926382/pexels-photo-5926382.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.8,
    reviews: 189,
    deliveryTime: '5 days',
    featured: true
  },
  {
    id: '3',
    title: 'Social Media Management',
    description: 'I will manage your social media accounts for a month, including content creation, scheduling, and engagement.',
    price: 80,
    category: 'marketing',
    image: 'https://images.pexels.com/photos/3850225/pexels-photo-3850225.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.7,
    reviews: 126,
    deliveryTime: '30 days'
  },
  {
    id: '4',
    title: 'SEO Optimization',
    description: 'I will optimize your website for search engines to improve ranking and increase organic traffic.',
    price: 90,
    category: 'marketing',
    image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.6,
    reviews: 98,
    deliveryTime: '7 days'
  },
  {
    id: '5',
    title: 'UI/UX Design',
    description: 'I will design a beautiful, user-friendly interface for your application or website with Figma.',
    price: 150,
    category: 'design',
    image: 'https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.9,
    reviews: 210,
    deliveryTime: '4 days',
    featured: true
  },
  {
    id: '6',
    title: 'Video Editing',
    description: 'I will professionally edit your video for YouTube, Instagram, or TikTok with engaging effects and transitions.',
    price: 70,
    category: 'video',
    image: 'https://images.pexels.com/photos/2510428/pexels-photo-2510428.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4.7,
    reviews: 156,
    deliveryTime: '3 days'
  }
];

export const categories: Category[] = [
  { id: '1', name: 'Design', slug: 'design', count: 15 },
  { id: '2', name: 'Development', slug: 'development', count: 23 },
  { id: '3', name: 'Marketing', slug: 'marketing', count: 18 },
  { id: '4', name: 'Video', slug: 'video', count: 12 },
  { id: '5', name: 'Writing', slug: 'writing', count: 20 },
];

export const reviews: Review[] = [
  {
    id: '1',
    serviceId: '1',
    userId: '101',
    userName: 'Alex Johnson',
    userAvatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 5,
    comment: 'Absolutely amazing work! The logo was exactly what I wanted for my brand.',
    date: '2023-09-15'
  },
  {
    id: '2',
    serviceId: '1',
    userId: '102',
    userName: 'Sarah Miller',
    userAvatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 4,
    comment: 'Great design and very responsive to feedback. Would recommend!',
    date: '2023-10-02'
  },
  {
    id: '3',
    serviceId: '2',
    userId: '103',
    userName: 'Michael Chen',
    userAvatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    rating: 5,
    comment: 'The website exceeded my expectations. Very professional and clean code.',
    date: '2023-09-28'
  }
];