import React from 'react';
import { services, categories } from '../data/services';
import Hero from '../components/Hero';
import FeaturedServices from '../components/FeaturedServices';
import Categories from '../components/Categories';
import Testimonial from '../components/Testimonial';
import CallToAction from '../components/CallToAction';

const Home: React.FC = () => {
  return (
    <div>
      <Hero />
      <FeaturedServices services={services} />
      <Categories categories={categories} />
      <Testimonial />
      <CallToAction />
    </div>
  );
};

export default Home;