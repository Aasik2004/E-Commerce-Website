import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { services, reviews } from '../data/services';
import { Star, Clock, CheckCircle, Award, User } from 'lucide-react';
import Button from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';

const ServiceDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const service = services.find(s => s.id === id);
  const serviceReviews = reviews.filter(review => review.serviceId === id);
  
  if (!service) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Service not found</h2>
        <p className="mb-6">The service you are looking for does not exist.</p>
        <Link to="/services">
          <Button variant="primary">Browse Services</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Service Info - 2/3 width on desktop */}
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{service.title}</h1>
          
          <div className="flex items-center mb-6">
            <div className="flex items-center mr-4">
              <Star className="h-5 w-5 text-amber-500 fill-amber-500" />
              <span className="ml-1 font-medium">{service.rating}</span>
              <span className="ml-1 text-gray-500">({service.reviews} reviews)</span>
            </div>
            <div className="flex items-center text-gray-500">
              <Clock className="h-5 w-5 mr-1" />
              <span>Delivery in {service.deliveryTime}</span>
            </div>
          </div>
          
          <div className="mb-8">
            <img 
              src={service.image} 
              alt={service.title} 
              className="w-full h-auto rounded-lg shadow-sm"
            />
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Service Description</h2>
            <p className="text-gray-700 mb-4">
              {service.description}
            </p>
            <p className="text-gray-700">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. Phasellus auctor, nisl eget ultricies lacinia, est nisi aliquam magna, eu faucibus nisl turpis eget quam. Donec volutpat, nulla eget aliquet aliquam, velit nisl dapibus dui, eget lacinia arcu urna eget magna.
            </p>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">What You'll Get</h2>
            <ul className="space-y-3">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>High-quality, professional work tailored to your needs</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Quick turnaround time with delivery in {service.deliveryTime}</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Unlimited revisions to ensure your complete satisfaction</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Full ownership rights to all deliverables</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>Ongoing support and consultation throughout the process</span>
              </li>
            </ul>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">About the Seller</h2>
            <div className="flex items-start">
              <img 
                src="https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Seller" 
                className="h-16 w-16 rounded-full object-cover mr-4"
              />
              <div>
                <h3 className="font-medium text-lg">John Doe</h3>
                <p className="text-gray-500 mb-2">Professional {service.category} Expert</p>
                <div className="flex items-center text-amber-500">
                  <Star className="h-4 w-4 fill-amber-500" />
                  <Star className="h-4 w-4 fill-amber-500" />
                  <Star className="h-4 w-4 fill-amber-500" />
                  <Star className="h-4 w-4 fill-amber-500" />
                  <Star className="h-4 w-4 fill-amber-500" />
                  <span className="ml-1 text-gray-700 text-sm">5.0 ({service.reviews})</span>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-4">Reviews</h2>
            {serviceReviews.length > 0 ? (
              <div className="space-y-6">
                {serviceReviews.map(review => (
                  <div key={review.id} className="border-b border-gray-200 pb-6">
                    <div className="flex items-start mb-3">
                      <img 
                        src={review.userAvatar} 
                        alt={review.userName} 
                        className="h-10 w-10 rounded-full object-cover mr-3"
                      />
                      <div>
                        <div className="flex items-center">
                          <h4 className="font-medium">{review.userName}</h4>
                          <span className="mx-2 text-gray-300">•</span>
                          <span className="text-sm text-gray-500">{review.date}</span>
                        </div>
                        <div className="flex text-amber-500 mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < review.rating ? 'fill-amber-500' : 'text-gray-300'}`} 
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    <p className="text-gray-700">{review.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No reviews yet.</p>
            )}
          </div>
        </div>
        
        {/* Order sidebar - 1/3 width on desktop */}
        <div className="lg:col-span-1">
          <div className="sticky top-24">
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xl font-bold">Price</h3>
                  <span className="text-2xl font-bold text-blue-600">${service.price}</span>
                </div>
                
                <p className="text-gray-700 mb-6">
                  Complete {service.category.toLowerCase()} service with {service.deliveryTime} turnaround
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-500 mr-2" />
                    <span>{service.deliveryTime} delivery</span>
                  </div>
                  <div className="flex items-center">
                    <Award className="h-5 w-5 text-gray-500 mr-2" />
                    <span>Satisfaction guaranteed</span>
                  </div>
                  <div className="flex items-center">
                    <User className="h-5 w-5 text-gray-500 mr-2" />
                    <span>Dedicated support</span>
                  </div>
                </div>
                
                <Button 
                  variant="primary" 
                  size="lg"
                  fullWidth
                  className="mb-3"
                >
                  Order Now
                </Button>
                
                <Button 
                  variant="outline" 
                  size="lg"
                  fullWidth
                >
                  Contact Seller
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetail;