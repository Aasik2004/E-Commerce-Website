import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { services, categories } from '../data/services';
import ServiceCard from '../components/ServiceCard';
import { Card } from '../components/ui/Card';
import { Search, Filter, Check } from 'lucide-react';

const Services: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const categoryParam = queryParams.get('category');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(categoryParam || '');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);
  const [sortBy, setSortBy] = useState('recommended');
  
  // Filter services based on search, category, and price
  const filteredServices = services.filter(service => {
    const matchesSearch = service.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          service.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? service.category === selectedCategory : true;
    const matchesPrice = service.price >= priceRange[0] && service.price <= priceRange[1];
    
    return matchesSearch && matchesCategory && matchesPrice;
  });
  
  // Sort services
  const sortedServices = [...filteredServices].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      default: // recommended
        return b.reviews - a.reviews;
    }
  });

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Services</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-24 p-6">
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </h3>
              <div className="relative mb-4">
                <input
                  type="text"
                  placeholder="Search services..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Categories</h3>
              <div className="space-y-2">
                <div 
                  className={`flex items-center cursor-pointer ${selectedCategory === '' ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                  onClick={() => setSelectedCategory('')}
                >
                  <span className="w-6">{selectedCategory === '' && <Check className="h-4 w-4" />}</span>
                  <span>All Categories</span>
                </div>
                {categories.map(category => (
                  <div 
                    key={category.id}
                    className={`flex items-center cursor-pointer ${selectedCategory === category.slug ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                    onClick={() => setSelectedCategory(category.slug)}
                  >
                    <span className="w-6">{selectedCategory === category.slug && <Check className="h-4 w-4" />}</span>
                    <span>{category.name}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Price Range</h3>
              <div className="flex items-center space-x-4 mb-2">
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full"
                />
              </div>
              <div className="flex items-center justify-between">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-3">Sort By</h3>
              <div className="space-y-2">
                {[
                  { value: 'recommended', label: 'Recommended' },
                  { value: 'rating', label: 'Top Rated' },
                  { value: 'price-low', label: 'Price: Low to High' },
                  { value: 'price-high', label: 'Price: High to Low' }
                ].map(option => (
                  <div 
                    key={option.value}
                    className={`flex items-center cursor-pointer ${sortBy === option.value ? 'text-blue-600 font-medium' : 'text-gray-700'}`}
                    onClick={() => setSortBy(option.value)}
                  >
                    <span className="w-6">{sortBy === option.value && <Check className="h-4 w-4" />}</span>
                    <span>{option.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
        
        {/* Services grid */}
        <div className="lg:col-span-3">
          {sortedServices.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedServices.map(service => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-2">No services found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Services;